package shopping;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class ShoppingCart {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int numOfProds = Integer.parseInt(scanner.nextLine());
		double totalCost = 0, totalDiscount = 0;
		Map<String, Product> prodMap = new LinkedHashMap<>();

		// Read input & create prods
		for (int i = 0; i < numOfProds; i++) {
			String[] prodItem = scanner.nextLine().split(" ");
			int quantity = Integer.parseInt(prodItem[0]);
			String prodName = "";
			double price = Double.parseDouble(prodItem[prodItem.length - 1]);

			// check for clearence item
			boolean isClearence = false;
			for (int j = 1; j < prodItem.length - 1; j++) {
				if (prodItem[j].equalsIgnoreCase("at")) {
					break;
				}
				if (prodItem[j].equalsIgnoreCase("clearence")) {
					isClearence = true;
				}
				prodName += prodItem[j] + " ";
			}
			prodName = prodName.trim();
			ProductType type= ProductType.getType(prodName);
			if (prodMap.containsKey(prodName)) {
				Product existed = prodMap.get(prodName);
				existed = new Product(prodName, price, type,
						existed.getQuantity() + quantity);
				prodMap.put(prodName, existed);
			} else {
				if(isClearence){
					prodMap.put(prodName, new ClearenceProduct(prodName, price, type, quantity));
				}else {
					prodMap.put(prodName, new Product(prodName, price, type, quantity));
				}
			}
		}

		// Calculate discount and cost

		for (Product product : prodMap.values()) {
			double discount = product.calculateDiscount();
			totalCost += product.getTotalPrice() - discount;
			totalDiscount += discount;
			System.out.printf("%d %s at %.2f%n", product.getQuantity(),
					product.getName(), product.getTotalPrice() - discount);
		}

		// Total cost and discount

		System.out.printf("Total amount: %.2f%n", totalCost);
		System.out.printf("You saved: %.2f%n", totalDiscount);
	}
}
