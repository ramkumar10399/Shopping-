package shopping;

class Product {
	private String name;
	private double price;
	private ProductType type;
	private int quantity;

	public Product(String name, double price, ProductType type, int quantity) {
		this.name = name;
		this.price = price;
		this.type = type;
		this.quantity = quantity;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public ProductType getType() {
		return type;
	}

	public int getQuantity() {
		return quantity;
	}

	// to calculate price for an product

	public double getTotalPrice() {
		return price * quantity;
	}

	public double calculateDiscount() {
		double discount = 0;
		switch (type) {
		case BOOK:
		case FOOD:
		case DRINKS:
			discount = getTotalPrice() * 0.05;
			break;
		case CLOTHES:
			discount = getTotalPrice() * 0.20;
			break;
		case OTHER:
			discount = getTotalPrice() * 0.03;
			break;
		}
		return discount;
	}

}
