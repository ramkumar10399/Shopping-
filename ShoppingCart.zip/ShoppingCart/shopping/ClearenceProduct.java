package shopping;

class ClearenceProduct extends Product {

	public ClearenceProduct(String name, double price, ProductType type,
			int quantity) {
		super(name, price, type, quantity);
	}

	@Override
	public double calculateDiscount() {
	    double normalDiscount = super.calculateDiscount();
		return normalDiscount + ((getTotalPrice()-normalDiscount) * 0.20);
	}

}
