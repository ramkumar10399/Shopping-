package shopping;

import java.util.HashMap;
import java.util.Map;

public enum ProductType {
	BOOK, FOOD, DRINKS, CLOTHES, OTHER;
	
	//Map to find the type of product
	private static final Map<String,ProductType> productTypeMap = new HashMap<>();

	//static block to populate the map
	static{
		productTypeMap.put("book", BOOK);
		productTypeMap.put("food", FOOD);
		productTypeMap.put("chocolate", FOOD);
		productTypeMap.put("dress", CLOTHES);
		productTypeMap.put("shirt", CLOTHES);
		productTypeMap.put("wine", DRINKS);
		
	}

	public static ProductType getType(String typeStr) {
		for(String str:productTypeMap.keySet()){
			if(typeStr.contains(str)){
				return productTypeMap.get(str);
			}
		}
		return OTHER;
	}
}
